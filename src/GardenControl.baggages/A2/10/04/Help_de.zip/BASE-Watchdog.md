### Watchdog

Ein Watchdog kann das Gerät automatisch neu starten, wenn es nicht mehr richtig funktioniert.