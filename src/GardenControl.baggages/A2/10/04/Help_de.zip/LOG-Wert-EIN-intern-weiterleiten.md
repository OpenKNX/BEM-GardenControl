﻿### Wert EIN intern weiterleiten

Wird dieses Auswahlfeld gewählt, wird ein für diesen Ausgang ermitteltes EIN-Signal an alle internen Eingänge weitergeleitet, die mit diesem Ausgang verbunden sind.

