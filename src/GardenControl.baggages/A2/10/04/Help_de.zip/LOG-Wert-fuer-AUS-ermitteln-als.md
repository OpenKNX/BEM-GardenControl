﻿### Wert für AUS ermitteln als

Der Wert des Ausgangs wird ermittelt durch die Berechnung der eingestellten Funktion.

