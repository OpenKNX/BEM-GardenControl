﻿### Eingang ist EIN wenn Wert gleich

Hier wird ein zu vergleichender Wert angegeben.

