﻿### Von-Wert

Hier wird der Von-Wert (also die untere Grenze) eines Wertebereichs angegeben.

