﻿### Nächste Zeile auswerten

Wird die Checkbox angeklickt, wird die Zeile mit dem Wert ausgewertet, sonst nicht.

